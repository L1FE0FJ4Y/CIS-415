Date: 11/6/2020

Author: Jay Shin

Description: I built the lab 5 on lab 4.
    
    This program will create children processes in n amount (./a.out 5, n will be 5)
    and make kids wait until parent gives them signal (a.k.a kill them...). To give some
    time to check, I executed iobound as lab 4 did. Then passing different signals to 
    check how well kids are behaving to their parent.
