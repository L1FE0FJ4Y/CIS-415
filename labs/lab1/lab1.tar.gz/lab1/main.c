#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main() {
  printf("Hello World!\n");

  return EXIT_SUCCESS;
}
